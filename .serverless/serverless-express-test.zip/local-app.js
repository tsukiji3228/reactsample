const app = require('./app')

app.listen(3000, () => {
    console.log('listening');
})

var local = '/test'